(async function(){
  const ORIG_FETCH = window.fetch.bind(window);
  async function ipc(endpoint, payload){
    switch(endpoint){
      case 'gpg/generate': return window.api.gpgGen(payload);
      case 'gpg/import':   return window.api.gpgImport(payload);
      case 'git/init':     return window.api.gitInit(payload);
      case 'git/push':     return window.api.gitPush(payload);
      case 'cert/generate':return window.api.certGenerate(payload);
      case 'cert/chain':   return window.api.makeChain(payload);
      case 'cms/make':     return window.api.cmsMake(payload);
      default: throw new Error('Unknown IPC endpoint: '+endpoint);
    }
  }
  window.fetch = async (input, init={}) => {
    try{
      const url = (typeof input==='string') ? input : input.url;
      const m = url.match(/\/api\/(.+)$/);
      if(m && init && init.method && init.method.toUpperCase() === 'POST'){
        const ep = m[1].replace(/^\/+/, '');
        const body = init.body && typeof init.body !== 'string' ? await init.body.text() : init.body;
        let payload = {};
        try { payload = body ? JSON.parse(body) : {}; } catch(e){}
        const res = await ipc(ep, payload);
        return new Response(JSON.stringify(res), { status: 200, headers: { 'Content-Type':'application/json' } });
      }
    }catch(e){ console.warn('IPC shim fallback to network:', e); }
    return ORIG_FETCH(input, init);
  };
})();