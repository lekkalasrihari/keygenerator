import argparse, sys, os, datetime, ipaddress
from typing import List
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, ec
from cryptography.x509.oid import NameOID, ExtendedKeyUsageOID

def make_key(key_type: str):
    if key_type.startswith('RSA-'):
        bits = int(key_type.split('-')[1])
        return rsa.generate_private_key(public_exponent=65537, key_size=bits)
    elif key_type == 'EC-P256':
        return ec.generate_private_key(ec.SECP256R1())
    else:
        raise SystemExit(f"Unsupported key type: {key_type}")

def save_pem_key(key, path):
    with open(path,'wb') as f:
        f.write(key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.TraditionalOpenSSL,
            serialization.NoEncryption()
        ))

def save_pem_cert(cert, path):
    with open(path,'wb') as f:
        f.write(cert.public_bytes(serialization.Encoding.PEM))

def name_from_cn(cn: str):
    return x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, cn or "CN-UNKNOWN")])

def basic_builder(subject, issuer, public_key, serial=None, not_after_days=825, is_ca=False, path_len=None):
    now = datetime.datetime.utcnow()
    serial = serial or x509.random_serial_number()
    b = x509.CertificateBuilder()        .subject_name(subject)        .issuer_name(issuer)        .public_key(public_key)        .serial_number(serial)        .not_valid_before(now - datetime.timedelta(minutes=1))        .not_valid_after(now + datetime.timedelta(days=not_after_days))

    b = b.add_extension(x509.BasicConstraints(ca=is_ca, path_length=path_len), critical=True)
    if is_ca:
        b = b.add_extension(
            x509.KeyUsage(digital_signature=True, key_encipherment=False,
                          key_cert_sign=True, key_agreement=False,
                          data_encipherment=False, content_commitment=False,
                          crl_sign=True, encipher_only=False, decipher_only=False),
            critical=True
        )
    else:
        b = b.add_extension(
            x509.KeyUsage(digital_signature=True, key_encipherment=True,
                          key_cert_sign=False, key_agreement=True,
                          data_encipherment=False, content_commitment=False,
                          crl_sign=False, encipher_only=False, decipher_only=False),
            critical=True
        )
        b = b.add_extension(
            x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH, ExtendedKeyUsageOID.CLIENT_AUTH]),
            critical=False
        )
    return b

def add_san(builder, san_list: List[str]):
    if not san_list: return builder
    san_objs = []
    for item in san_list:
        item = item.strip()
        if not item: continue
        if item.upper().startswith('DNS:'):
            san_objs.append(x509.DNSName(item.split(':',1)[1]))
        elif item.upper().startswith('IP:'):
            san_objs.append(x509.IPAddress(ipaddress.ip_address(item.split(':',1)[1])))
        else:
            san_objs.append(x509.DNSName(item))
    return builder.add_extension(x509.SubjectAlternativeName(san_objs), critical=False)

def self_sign(subject_key, subject_name, days, is_ca=False, path_len=None, san=None):
    builder = basic_builder(subject_name, subject_name, subject_key.public_key(), not_after_days=days, is_ca=is_ca, path_len=path_len)
    if san: builder = add_san(builder, san)
    algo = hashes.SHA256()
    return builder.sign(private_key=subject_key, algorithm=algo)

def sign_with_issuer(subject_key, subject_name, issuer_cert, issuer_key, days, is_ca=False, path_len=None, san=None):
    builder = basic_builder(subject_name, issuer_cert.subject, subject_key.public_key(), not_after_days=days, is_ca=is_ca, path_len=path_len)
    if san: builder = add_san(builder, san)
    algo = hashes.SHA256()
    return builder.sign(private_key=issuer_key, algorithm=algo)

def ensure_dir(p):
    os.makedirs(p, exist_ok=True)
    return p

def do_generate(args):
    out = ensure_dir(args.outdir)
    t = args.type.upper()

    key = make_key(args.key_type)

    if t == 'ROOTCA':
        folder = ensure_dir(os.path.join(out, 'ROOTCA'))
        key_path = os.path.join(folder, 'ROOTCA.key')
        crt_path = os.path.join(folder, 'ROOTCA.pem')
        save_pem_key(key, key_path)
        cert = self_sign(key, name_from_cn(args.cn or 'ROOTCA'), args.days, is_ca=True, path_len=2)
        save_pem_cert(cert, crt_path)
        print(f"ROOTCA created: {crt_path}")
        return

    if t == 'SCA':
        if not (args.issuer_cert and args.issuer_key):
            sys.exit("SCA requires --issuer-cert and --issuer-key (Root CA)")
        folder = ensure_dir(os.path.join(out, 'SCA'))
        key_path = os.path.join(folder, 'SCA.key')
        crt_path = os.path.join(folder, 'SCA.pem')
        save_pem_key(key, key_path)
        issuer_cert = x509.load_pem_x509_certificate(open(args.issuer_cert,'rb').read())
        issuer_key = serialization.load_pem_private_key(open(args.issuer_key,'rb').read(), password=None)
        cert = sign_with_issuer(key, name_from_cn(args.cn or 'SCA'), issuer_cert, issuer_key, args.days, is_ca=True, path_len=1)
        save_pem_cert(cert, crt_path)
        print(f"SCA created: {crt_path}")
        return

    if t == 'CA':
        if not (args.issuer_cert and args.issuer_key):
            sys.exit("CA requires --issuer-cert and --issuer-key (SCA)")
        folder = ensure_dir(os.path.join(out, 'CA'))
        key_path = os.path.join(folder, 'CA.key')
        crt_path = os.path.join(folder, 'CA.pem')
        save_pem_key(key, key_path)
        issuer_cert = x509.load_pem_x509_certificate(open(args.issuer_cert,'rb').read())
        issuer_key = serialization.load_pem_private_key(open(args.issuer_key,'rb').read(), password=None)
        cert = sign_with_issuer(key, name_from_cn(args.cn or 'CA'), issuer_cert, issuer_key, args.days, is_ca=True, path_len=0)
        save_pem_cert(cert, crt_path)
        print(f"CA created: {crt_path}")
        return

    if t in ('TLS','UP'):
        folder = ensure_dir(os.path.join(out, t))
        key_path = os.path.join(folder, f'{t}.key')
        crt_path = os.path.join(folder, f'{t}.pem')
        save_pem_key(key, key_path)
        subject = name_from_cn(args.cn or t)
        if args.self_signed:
            cert = self_sign(key, subject, args.days, is_ca=False, san=args.san or [])
        else:
            if not (args.issuer_cert and args.issuer_key):
                sys.exit(f"{t} requires --issuer-cert and --issuer-key unless --self-signed is used")
            issuer_cert = x509.load_pem_x509_certificate(open(args.issuer_cert,'rb').read())
            issuer_key = serialization.load_pem_private_key(open(args.issuer_key,'rb').read(), password=None)
            cert = sign_with_issuer(key, subject, issuer_cert, issuer_key, args.days, is_ca=False, san=args.san or [])
        save_pem_cert(cert, crt_path)
        print(f"{t} created: {crt_path}")
        return

    sys.exit(f"Unsupported type {t}")

def do_chain(args):
    parts = []
    with open(args.leaf,'rb') as f: parts.append(f.read())
    for p in args.issuers:
        with open(p,'rb') as f: parts.append(f.read())
    with open(args.out,'wb') as f:
        for part in parts: f.write(part)
    print(f"chain.pem created at {args.out}")

def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest='cmd', required=True)

    g = sub.add_parser('generate')
    g.add_argument('--type', required=True, help='ROOTCA|SCA|CA|TLS|UP')
    g.add_argument('--key-type', required=True, help='RSA-2048|RSA-3072|RSA-4096|EC-P256')
    g.add_argument('--outdir', required=True)
    g.add_argument('--cn')
    g.add_argument('--san', nargs='*')
    g.add_argument('--days', type=int, default=825)
    g.add_argument('--issuer-cert')
    g.add_argument('--issuer-key')
    g.add_argument('--self-signed', action='store_true')
    g.set_defaults(func=do_generate)

    c = sub.add_parser('chain')
    c.add_argument('--leaf', required=True)
    c.add_argument('--issuers', nargs='+', required=True)
    c.add_argument('--out', required=True)
    c.set_defaults(func=do_chain)

    args = ap.parse_args()
    args.func(args)

if __name__ == '__main__':
    main()
