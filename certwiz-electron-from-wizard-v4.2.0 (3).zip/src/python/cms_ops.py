import argparse
from cryptography.hazmat.primitives.serialization import load_pem_private_key, Encoding
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.serialization import pkcs7
from cryptography import x509

def make_cms(input_file, cert_file, key_file, out_file):
    data = open(input_file, 'rb').read()
    cert = x509.load_pem_x509_certificate(open(cert_file,'rb').read())
    key = load_pem_private_key(open(key_file,'rb').read(), password=None)

    builder = pkcs7.PKCS7SignatureBuilder().set_data(data).add_signer(cert, key, hashes.SHA256())
    cms = builder.sign(Encoding.DER, [pkcs7.PKCS7Options.DetachedSignature])
    with open(out_file,'wb') as f:
      f.write(cms)
    print(f"CMS package created at {out_file}")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--input', required=True)
    ap.add_argument('--cert', required=True)
    ap.add_argument('--key', required=True)
    ap.add_argument('--out', required=True)
    args = ap.parse_args()
    make_cms(args.input, args.cert, args.key, args.out)

if __name__ == '__main__':
    main()
