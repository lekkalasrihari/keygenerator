const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const { spawn } = require('child_process');
const log = require('electron-log');

process.env.ELECTRON_DISABLE_SECURITY_WARNINGS = 'true';

const RES = app.isPackaged ? process.resourcesPath : process.cwd();
const VENDOR = path.join(RES, 'vendor');
const BIN = path.join(VENDOR, 'bin');

function findExe(cands){ for(const c of cands){ if(c) return path.normalize(c); } return null; }
function resolveGit(){ return findExe([path.join(VENDOR,'git','cmd','git.exe'), path.join(VENDOR,'git','bin','git.exe'), 'git']); }
function resolveGpg(){ return findExe([path.join(VENDOR,'gnupg','bin','gpg.exe'), path.join(VENDOR,'gnupg','gpg.exe'), 'gpg']); }
function resolveEngine(n){ return findExe([path.join(BIN, n + (process.platform==='win32'?'.exe':''))]); }

function runExe(cmd, args=[], cwd, env){
  log.info('RUN:', cmd, args.join(' '));
  const p = spawn(`"${cmd}"`, args.map(a => `"${a}"`), { shell: true, cwd, env });
  let out='', err='';
  p.stdout.on('data', d => out += d.toString());
  p.stderr.on('data', d => err += d.toString());
  return new Promise((res, rej) => p.on('close', code => code===0 ? res({out,err}) : rej(new Error(err || ('Exit '+code)))));
}

function createWindow(){
  const win = new BrowserWindow({
    width: 1300, height: 860,
    webPreferences: { preload: path.join(__dirname,'preload.js'), contextIsolation: true, nodeIntegration: false }
  });
  win.removeMenu();
  win.loadFile(path.join(__dirname, 'renderer', 'pages', 'index.html'));
}

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length===0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

// IPC
ipcMain.handle('dialog:selectDir', async () => {
  const r = await dialog.showOpenDialog({ properties: ['openDirectory','createDirectory'] });
  if (r.canceled || !r.filePaths?.length) return null;
  return r.filePaths[0];
});
ipcMain.handle('openInFolder', async (_e, p) => { shell.showItemInFolder(p); return true; });

ipcMain.handle('cert:generate', async (_e, p) => {
  const eng = resolveEngine('cert_engine'); if(!eng) throw new Error('Engine missing');
  const args = ['generate','--type',p.type,'--key-type',p.keyType,'--outdir',p.outDir];
  if(p.cn) args.push('--cn', p.cn);
  if(p.san?.length) args.push('--san', ...p.san);
  if(p.validDays) args.push('--days', String(p.validDays));
  if(p.issuerCert) args.push('--issuer-cert', p.issuerCert);
  if(p.issuerKey) args.push('--issuer-key', p.issuerKey);
  if(p.selfSigned) args.push('--self-signed');
  const {out,err} = await runExe(eng, args);
  return { ok:true, logs: out + (err||'') };
});

ipcMain.handle('cert:chain', async (_e, p) => {
  const eng = resolveEngine('cert_engine'); if(!eng) throw new Error('Engine missing');
  const args = ['chain', '--leaf', p.leaf, '--issuers', ...p.issuers, '--out', p.out];
  const {out,err} = await runExe(eng, args);
  return { ok:true, logs: out + (err||'') };
});

ipcMain.handle('cms:make', async (_e, p) => {
  const cms = resolveEngine('cms_ops'); if(!cms) throw new Error('CMS engine missing');
  const args = ['--input', p.input, '--cert', p.cert, '--key', p.key, '--out', p.out];
  const {out,err} = await runExe(cms, args);
  return { ok:true, logs: out + (err||'') };
});

ipcMain.handle('gpg:gen', async (_e, p) => {
  const gpg = resolveGpg(); if(!gpg) throw new Error('GPG missing');
  const fs = require('fs'), os = require('os');
  const tmp = path.join(os.tmpdir(), 'gpg-batch-' + Date.now() + '.conf');
  const batch = [
    'Key-Type: ' + (p.type || 'default'),
    ...(p.type==='RSA' && p.keyLength ? ['Key-Length: ' + p.keyLength] : []),
    'Name-Real: ' + p.name,
    'Name-Email: ' + p.email,
    'Expire-Date: 0',
    '%commit','%echo done'
  ].join('\n');
  fs.writeFileSync(tmp, batch);
  try {
    const env = { ...process.env, GNUPGHOME: process.env.GNUPGHOME || require('os').homedir() + '\\AppData\\Roaming\\gnupg' };
    const {out} = await runExe(gpg, ['--batch','--generate-key', tmp], undefined, env);
    return { ok:true, out };
  } finally { try { fs.unlinkSync(tmp); } catch {} }
});

ipcMain.handle('gpg:import', async (_e, p) => {
  const gpg = resolveGpg();
  const env = { ...process.env, GNUPGHOME: process.env.GNUPGHOME || require('os').homedir() + '\\AppData\\Roaming\\gnupg' };
  const {out} = await runExe(gpg, ['--import', p.filePath], undefined, env);
  return { ok:true, out };
});

ipcMain.handle('git:init', async (_e, p) => {
  const git = resolveGit(); const repo = p.repoPath;
  await runExe(git, ['init'], repo);
  if(p.gpgKey){ await runExe(git, ['config','user.signingkey',p.gpgKey], repo); await runExe(git, ['config','commit.gpgsign','true'], repo); }
  if(p.userName) await runExe(git, ['config','user.name',p.userName], repo);
  if(p.userEmail) await runExe(git, ['config','user.email',p.userEmail], repo);
  return { ok:true };
});

ipcMain.handle('git:push', async (_e, p) => {
  const git = resolveGit(); const repo = p.repoPath;
  await runExe(git, ['add','.'], repo);
  await runExe(git, ['commit','-m', p.message || 'update'], repo);
  if(p.remote && p.branch){
    try { await runExe(git, ['remote','add','origin', p.remote], repo); } catch {}
    await runExe(git, ['push','-u','origin', p.branch], repo);
  }
  return { ok:true };
});
