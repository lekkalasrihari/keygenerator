const { execSync } = require('child_process');
function tryVersion(cmd, args='--version'){ try{ execSync(`${cmd} ${args}`, {stdio:'ignore', shell:true}); return true; }catch{ return false; } }
console.log('Checking Node...'); tryVersion('node','-v') ? console.log('OK: node') : console.log('Missing: node');
console.log('Checking npm...');  tryVersion('npm','-v')  ? console.log('OK: npm')  : console.log('Missing: npm');
const candidates = []; if (process.env.CERTWIZ_PYTHON) candidates.push(`"${process.env.CERTWIZ_PYTHON}"`); candidates.push('py -3','python3','python');
let found = null; for (const c of candidates) { if (tryVersion(c,'--version')) { found = c; break; } }
if (found) console.log('OK: python via', found); else { console.log('Missing: python (set CERTWIZ_PYTHON to C:\\Python311\\python.exe)'); process.exitCode = 1; }
