// Build PyInstaller engines -> vendor/bin/*.exe
const { execSync } = require('child_process'); const path = require('path'); const fs = require('fs');
function ok(cmd){ try{ execSync(`${cmd} --version`, {stdio:'ignore', shell:true}); return true; } catch { return false; } }
const pyCands = []; if (process.env.CERTWIZ_PYTHON) pyCands.push(`"${process.env.CERTWIZ_PYTHON}"`); pyCands.push('py -3','python3','python');
let PY = null; for (const c of pyCands) { if (ok(c)) { PY = c; break; } }
if (!PY) { console.error('Python not found. Set CERTWIZ_PYTHON to your python.exe (e.g. C:\\Python311\\python.exe)'); process.exit(1); }
function run(cmd, cwd){ execSync(cmd, { stdio:'inherit', cwd, shell:true }); }
const proj = process.cwd(); const buildDir = path.join(proj,'build'); const venv = path.join(buildDir,'venv'); fs.mkdirSync(buildDir, { recursive: true });
console.log('Using Python =>', PY); console.log('Creating venv + installing deps...'); run(`${PY} -m venv "${venv}"`);
const pip = `"${path.join(venv,'Scripts','pip.exe')}"`; const python = `"${path.join(venv,'Scripts','python.exe')}"`;
run(`${pip} install --upgrade pip`); run(`${pip} install cryptography==43.0.3 pyinstaller==6.10`);
console.log('Building cert_engine.exe ...'); run(`${python} -m PyInstaller -F src/python/cert_engine.py --name cert_engine`);
console.log('Building cms_ops.exe ...'); run(`${python} -m PyInstaller -F src/python/cms_ops.py --name cms_ops`);
const dist = path.join(proj,'dist'); const vendorBin = path.join(proj,'vendor','bin'); fs.mkdirSync(vendorBin, { recursive: true });
fs.copyFileSync(path.join(dist,'cert_engine.exe'), path.join(vendorBin,'cert_engine.exe'));
fs.copyFileSync(path.join(dist,'cms_ops.exe'), path.join(vendorBin,'cms_ops.exe'));
console.log('Engines staged at vendor/bin/*.exe');
