# CertWiz Desktop (v4.2.0) — EB removed

## Build on Windows (PowerShell)
```powershell
npm run check:env
npm install
npm run build:win
# → dist/CertWiz Setup 4.2.0.exe
```
If vendor prep fails due to network, download MinGit zip to `vendor\cache\mingit.zip` and latest `gnupg-w32-*.exe` to `vendor\cache\gnupg.exe`, then re-run `npm run build:win`.

End users install a single EXE — no Git/GPG/Python required.
