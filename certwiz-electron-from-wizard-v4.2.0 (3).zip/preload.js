const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('api', {
  selectDir: () => ipcRenderer.invoke('dialog:selectDir'),
  openInFolder: (p) => ipcRenderer.invoke('openInFolder', p),
  certGenerate: (p) => ipcRenderer.invoke('cert:generate', p),
  makeChain: (p) => ipcRenderer.invoke('cert:chain', p),
  cmsMake: (p) => ipcRenderer.invoke('cms:make', p),
  gpgGen: (p) => ipcRenderer.invoke('gpg:gen', p),
  gpgImport: (p) => ipcRenderer.invoke('gpg:import', p),
  gitInit: (p) => ipcRenderer.invoke('git:init', p),
  gitPush: (p) => ipcRenderer.invoke('git:push', p),
});
